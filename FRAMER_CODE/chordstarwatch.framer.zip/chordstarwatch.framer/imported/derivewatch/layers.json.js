window.__imported__ = window.__imported__ || {};
window.__imported__["derivewatch/layers.json.js"] = [
	{
		"id": 42,
		"name": "arrived_bg",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 337,
			"height": 384
		},
		"maskFrame": null,
		"image": {
			"path": "images/arrived_bg.png",
			"frame": {
				"x": 0,
				"y": 0,
				"width": 337,
				"height": 384
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1613980504"
	},
	{
		"id": 45,
		"name": "arrived_main",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 337,
			"height": 384
		},
		"maskFrame": null,
		"image": {
			"path": "images/arrived_main.png",
			"frame": {
				"x": 36,
				"y": 100,
				"width": 266,
				"height": 245
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1613861158"
	},
	{
		"id": 36,
		"name": "poi_bg",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 337,
			"height": 384
		},
		"maskFrame": null,
		"image": {
			"path": "images/poi_bg.png",
			"frame": {
				"x": 0,
				"y": 0,
				"width": 337,
				"height": 384
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1614993251"
	},
	{
		"id": 39,
		"name": "poi_main",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 337,
			"height": 384
		},
		"maskFrame": null,
		"image": {
			"path": "images/poi_main.png",
			"frame": {
				"x": 36,
				"y": 100,
				"width": 266,
				"height": 251
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1614873957"
	},
	{
		"id": 30,
		"name": "directions_bg",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 337,
			"height": 384
		},
		"maskFrame": null,
		"image": {
			"path": "images/directions_bg.png",
			"frame": {
				"x": 0,
				"y": 0,
				"width": 337,
				"height": 384
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1184130272"
	},
	{
		"id": 33,
		"name": "directions_main",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 337,
			"height": 384
		},
		"maskFrame": null,
		"image": {
			"path": "images/directions_main.png",
			"frame": {
				"x": 36,
				"y": 100,
				"width": 266,
				"height": 245
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1615857155"
	},
	{
		"id": 22,
		"name": "request_bg",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 337,
			"height": 384
		},
		"maskFrame": null,
		"image": {
			"path": "images/request_bg.png",
			"frame": {
				"x": 0,
				"y": 0,
				"width": 337,
				"height": 384
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1617763744"
	},
	{
		"id": 25,
		"name": "request_main",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 337,
			"height": 384
		},
		"maskFrame": null,
		"image": {
			"path": "images/request_main.png",
			"frame": {
				"x": 34,
				"y": 99,
				"width": 266,
				"height": 231
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1617584940"
	},
	{
		"id": 9,
		"name": "splash_bg",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 337,
			"height": 384
		},
		"maskFrame": null,
		"image": {
			"path": "images/splash_bg.png",
			"frame": {
				"x": 0,
				"y": 0,
				"width": 337,
				"height": 384
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1618717027"
	},
	{
		"id": 13,
		"name": "splash_curious",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 337,
			"height": 384
		},
		"maskFrame": null,
		"image": {
			"path": "images/splash_curious.png",
			"frame": {
				"x": 60,
				"y": 251,
				"width": 217,
				"height": 74
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1618657446"
	},
	{
		"id": 17,
		"name": "splash_notcurious",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 337,
			"height": 384
		},
		"maskFrame": null,
		"image": {
			"path": "images/splash_notcurious.png",
			"frame": {
				"x": 60,
				"y": 251,
				"width": 217,
				"height": 74
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1618597898"
	}
]