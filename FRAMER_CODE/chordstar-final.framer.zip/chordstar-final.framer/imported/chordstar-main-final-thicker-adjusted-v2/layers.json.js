window.__imported__ = window.__imported__ || {};
window.__imported__["chordstar-main-final-thicker-adjusted-v2/layers.json.js"] = [
	{
		"id": 3,
		"name": "splashScreen",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": {
			"path": "images/splashScreen.png",
			"frame": {
				"x": 0,
				"y": 0,
				"width": 750,
				"height": 1334
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1677344474"
	},
	{
		"id": 103,
		"name": "canvas",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": {
			"path": "images/canvas.png",
			"frame": {
				"x": 0,
				"y": 0,
				"width": 750,
				"height": 1334
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "2043919779"
	},
	{
		"id": 57,
		"name": "pickSong",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": {
			"path": "images/pickSong.png",
			"frame": {
				"x": 65,
				"y": 87,
				"width": 655,
				"height": 1032
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "246164849"
	},
	{
		"id": 823,
		"name": "beginTextEntry",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": {
			"path": "images/beginTextEntry.png",
			"frame": {
				"x": 147,
				"y": 931,
				"width": 370,
				"height": 58
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "399598107"
	},
	{
		"id": 826,
		"name": "letters",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": null,
		"imageType": null,
		"children": [
			{
				"id": 798,
				"name": "pickSongStateOfGrace",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/pickSongStateOfGrace.png",
					"frame": {
						"x": 374,
						"y": 952,
						"width": 17,
						"height": 22
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "14926522"
			},
			{
				"id": 795,
				"name": "pickSongStateOfGrac",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/pickSongStateOfGrac.png",
					"frame": {
						"x": 354,
						"y": 952,
						"width": 17,
						"height": 22
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "492322975"
			},
			{
				"id": 792,
				"name": "pickSongStateOfGra",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/pickSongStateOfGra.png",
					"frame": {
						"x": 334,
						"y": 952,
						"width": 17,
						"height": 22
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "739150860"
			},
			{
				"id": 789,
				"name": "pickSongStateOfGr",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/pickSongStateOfGr.png",
					"frame": {
						"x": 324,
						"y": 952,
						"width": 9,
						"height": 22
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "227965122"
			},
			{
				"id": 786,
				"name": "pickSongStateOfG",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/pickSongStateOfG.png",
					"frame": {
						"x": 296,
						"y": 945,
						"width": 21,
						"height": 29
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "1588822548"
			},
			{
				"id": 783,
				"name": "pickSongStateOf",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/pickSongStateOf.png",
					"frame": {
						"x": 275,
						"y": 943,
						"width": 11,
						"height": 31
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "922329551"
			},
			{
				"id": 780,
				"name": "pickSongStateO",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/pickSongStateO.png",
					"frame": {
						"x": 253,
						"y": 952,
						"width": 19,
						"height": 22
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "923849047"
			},
			{
				"id": 777,
				"name": "pickSongState",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/pickSongState.png",
					"frame": {
						"x": 225,
						"y": 952,
						"width": 17,
						"height": 22
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "1195407368"
			},
			{
				"id": 774,
				"name": "pickSongStat",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/pickSongStat.png",
					"frame": {
						"x": 212,
						"y": 947,
						"width": 11,
						"height": 27
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "1875498539"
			},
			{
				"id": 771,
				"name": "pickSongSta",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/pickSongSta.png",
					"frame": {
						"x": 193,
						"y": 952,
						"width": 17,
						"height": 22
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "1836351306"
			},
			{
				"id": 768,
				"name": "pickSongSt",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/pickSongSt.png",
					"frame": {
						"x": 180,
						"y": 947,
						"width": 11,
						"height": 27
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "1836898392"
			},
			{
				"id": 761,
				"name": "pickSongS",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/pickSongS.png",
					"frame": {
						"x": 159,
						"y": 945,
						"width": 20,
						"height": 29
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "676194925"
			}
		],
		"modification": "1535165856"
	},
	{
		"id": 365,
		"name": "tuner",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": {
			"path": "images/tuner.png",
			"frame": {
				"x": 0,
				"y": 87,
				"width": 750,
				"height": 703
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "84016059"
	},
	{
		"id": 399,
		"name": "myProgress",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": {
			"path": "images/myProgress.png",
			"frame": {
				"x": 31,
				"y": 87,
				"width": 703,
				"height": 780
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1382537078"
	},
	{
		"id": 448,
		"name": "menuSidebar",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": {
			"path": "images/menuSidebar.png",
			"frame": {
				"x": 0,
				"y": 55,
				"width": 750,
				"height": 1279
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "181995022"
	},
	{
		"id": 90,
		"name": "taylorSwift",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": {
			"path": "images/taylorSwift.png",
			"frame": {
				"x": 28,
				"y": 86,
				"width": 692,
				"height": 1179
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "2061379529"
	},
	{
		"id": 341,
		"name": "listeningTo",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": {
			"path": "images/listeningTo.png",
			"frame": {
				"x": 28,
				"y": 86,
				"width": 692,
				"height": 1210
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1015624410"
	},
	{
		"id": 830,
		"name": "pauseButton",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": {
			"path": "images/pauseButton.png",
			"frame": {
				"x": 324,
				"y": 980,
				"width": 103,
				"height": 95
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1379603960"
	},
	{
		"id": 876,
		"name": "dots",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": null,
		"imageType": null,
		"children": [
			{
				"id": 874,
				"name": "dot13",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/dot13.png",
					"frame": {
						"x": 439,
						"y": 1122,
						"width": 15,
						"height": 15
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "238758209"
			},
			{
				"id": 871,
				"name": "dot12",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/dot12.png",
					"frame": {
						"x": 419,
						"y": 1122,
						"width": 15,
						"height": 15
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "518913821"
			},
			{
				"id": 868,
				"name": "dot11",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/dot11.png",
					"frame": {
						"x": 398,
						"y": 1122,
						"width": 15,
						"height": 15
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "277606876"
			},
			{
				"id": 865,
				"name": "dot10",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/dot10.png",
					"frame": {
						"x": 373,
						"y": 1122,
						"width": 15,
						"height": 15
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "2124119683"
			},
			{
				"id": 862,
				"name": "dot9",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/dot9.png",
					"frame": {
						"x": 345,
						"y": 1122,
						"width": 15,
						"height": 15
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "1479524663"
			},
			{
				"id": 859,
				"name": "dot8",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/dot8.png",
					"frame": {
						"x": 321,
						"y": 1122,
						"width": 15,
						"height": 15
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "1234002994"
			},
			{
				"id": 856,
				"name": "dot7",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/dot7.png",
					"frame": {
						"x": 297,
						"y": 1122,
						"width": 15,
						"height": 15
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "1145337841"
			},
			{
				"id": 853,
				"name": "dot6",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/dot6.png",
					"frame": {
						"x": 277,
						"y": 1122,
						"width": 15,
						"height": 15
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "1153410176"
			},
			{
				"id": 850,
				"name": "dot5",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/dot5.png",
					"frame": {
						"x": 257,
						"y": 1122,
						"width": 15,
						"height": 15
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "1277213532"
			},
			{
				"id": 847,
				"name": "dot4",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/dot4.png",
					"frame": {
						"x": 237,
						"y": 1122,
						"width": 15,
						"height": 15
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "1562940372"
			},
			{
				"id": 844,
				"name": "dot3",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/dot3.png",
					"frame": {
						"x": 215,
						"y": 1122,
						"width": 15,
						"height": 15
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "1161134772"
			},
			{
				"id": 841,
				"name": "dot2",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/dot2.png",
					"frame": {
						"x": 192,
						"y": 1122,
						"width": 15,
						"height": 15
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "1500751802"
			},
			{
				"id": 835,
				"name": "dot",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/dot.png",
					"frame": {
						"x": 173,
						"y": 1122,
						"width": 15,
						"height": 15
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "380171295"
			}
		],
		"modification": "148112541"
	},
	{
		"id": 480,
		"name": "turnWatch",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": {
			"path": "images/turnWatch.png",
			"frame": {
				"x": 28,
				"y": 86,
				"width": 692,
				"height": 898
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1353140258"
	},
	{
		"id": 170,
		"name": "nowLearning",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": {
			"path": "images/nowLearning.png",
			"frame": {
				"x": 28,
				"y": 86,
				"width": 692,
				"height": 1193
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1344931755"
	},
	{
		"id": 241,
		"name": "endSession",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": {
			"path": "images/endSession.png",
			"frame": {
				"x": 28,
				"y": 86,
				"width": 692,
				"height": 1207
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "2004847826"
	},
	{
		"id": 296,
		"name": "playbackSession",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": {
			"path": "images/playbackSession.png",
			"frame": {
				"x": 28,
				"y": 86,
				"width": 692,
				"height": 1207
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "492562844"
	}
]